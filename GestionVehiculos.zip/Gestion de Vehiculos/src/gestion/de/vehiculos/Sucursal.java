/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestion.de.vehiculos;

import java.util.ArrayList;

/**
 *
 * @author W608-PCXX
 */
public class Sucursal {
    
    private String idSucursal, nombreSucursal;
    private ArrayList<Vehiculo> vehiculosDisponibles;

    public Sucursal(String idSucursal, String nombreSucursal, ArrayList<Vehiculo> vehiculosDisponibles) {
        this.idSucursal = idSucursal;
        this.nombreSucursal = nombreSucursal;
        this.vehiculosDisponibles = vehiculosDisponibles;
    }

    public Sucursal() {
    }

    public String getIdSucursal() {
        return idSucursal;
    }

    public void setIdSucursal(String idSucursal) {
        this.idSucursal = idSucursal;
    }

    public String getNombreSucursal() {
        return nombreSucursal;
    }

    public void setNombreSucursal(String nombreSucursal) {
        this.nombreSucursal = nombreSucursal;
    }

    public ArrayList<Vehiculo> getVehiculosDisponibles() {
        return vehiculosDisponibles;
    }

    public void setVehiculosDisponibles(ArrayList<Vehiculo> vehiculosDisponibles) {
        this.vehiculosDisponibles = vehiculosDisponibles;
    }

    @Override
    public String toString() {
        return "Sucursal{" + "idSucursal=" + idSucursal + ", nombreSucursal=" + nombreSucursal + ", vehiculosDisponibles=" + vehiculosDisponibles + '}';
    }
    
    public void listarVehiculos(){
        System.out.println("ID: "+this.idSucursal);
        System.out.println("Nombre: "+this.nombreSucursal);
        System.out.println("***Autos disponibles***");
        for(Vehiculo auto:this.vehiculosDisponibles){
            System.out.println(auto);
        }
    }
}
