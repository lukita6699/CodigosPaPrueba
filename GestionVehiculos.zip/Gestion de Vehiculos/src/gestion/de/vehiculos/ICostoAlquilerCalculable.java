/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package gestion.de.vehiculos;

/**
 *
 * @author W608-PCXX
 */
public interface ICostoAlquilerCalculable {
    
    public void calcularCostoAlquiler();
}
