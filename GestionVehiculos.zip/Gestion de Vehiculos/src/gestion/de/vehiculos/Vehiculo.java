/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestion.de.vehiculos;

/**
 *
 * @author Calfun
 */
public abstract class Vehiculo {
    
    private String idVehiculo, modelo;
    private int costoBaseAlquiler;

    public Vehiculo(String idVehiculo, String modelo, int costoBaseAlquiler) {
        this.idVehiculo = idVehiculo;
        this.modelo = modelo;
        this.costoBaseAlquiler = costoBaseAlquiler;
    }

    public Vehiculo() {
    }

    public String getIdVehiculo() {
        return idVehiculo;
    }

    public void setIdVehiculo(String idVehiculo) {
        this.idVehiculo = idVehiculo;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getCostoBaseAlquiler() {
        return costoBaseAlquiler;
    }

    public void setCostoBaseAlquiler(int costoBaseAlquiler) {
        this.costoBaseAlquiler = costoBaseAlquiler;
    }

    @Override
    public String toString() {
        return "idVehiculo=" + idVehiculo + ", modelo=" + modelo + ", costoBaseAlquiler=" + costoBaseAlquiler ;
    }
    
    
}
