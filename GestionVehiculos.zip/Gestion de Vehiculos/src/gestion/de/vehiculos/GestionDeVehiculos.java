/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestion.de.vehiculos;

import java.awt.List;
import java.util.ArrayList;

/**
 *
 * @author W608-PCXX
 */
public class GestionDeVehiculos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        VehiculoLujo vLujo1=new VehiculoLujo("001","Mclaren",7000);
        VehiculoLujo vLujo2=new VehiculoLujo("002","Subaru Impreza",7000);
        VehiculoLujo vLujo3=new VehiculoLujo("003","V16",7000);
        
        VehiculoEstandar vEstandar1=new VehiculoEstandar("001","Spark",5000);
        VehiculoEstandar vEstandar2=new VehiculoEstandar("002","Yaris",5000);
        VehiculoEstandar vEstandar3=new VehiculoEstandar("003","Corsa",5000);
    
        ArrayList<Vehiculo> listaVehiculos1=new ArrayList<Vehiculo>();
        ArrayList<Vehiculo> listaVehiculos2=new ArrayList<Vehiculo>();
        
        listaVehiculos1.add(vLujo1);
        listaVehiculos1.add(vLujo3);
        listaVehiculos1.add(vEstandar2);
        
        listaVehiculos2.add(vLujo2);
        listaVehiculos2.add(vEstandar1);
        listaVehiculos2.add(vEstandar3);
        
        Sucursal suc1=new Sucursal("100","Osorno",listaVehiculos1);
        Sucursal suc2=new Sucursal("200","Puerto Montt",listaVehiculos2);
        
        suc1.listarVehiculos();
        System.out.println("");
        suc2.listarVehiculos();
        
    }
    
}
