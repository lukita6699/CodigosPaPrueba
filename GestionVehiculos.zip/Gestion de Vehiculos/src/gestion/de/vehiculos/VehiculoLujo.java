/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestion.de.vehiculos;

/**
 *
 * @author W608-PCXX
 */
public class VehiculoLujo extends Vehiculo implements ICostoAlquilerCalculable {

    public VehiculoLujo(String idVehiculo, String modelo, int costoBaseAlquiler) {
        super(idVehiculo, modelo, costoBaseAlquiler);
    }

    public VehiculoLujo() {
    }

    
    @Override
    public void calcularCostoAlquiler() {
        
    }
    
    
}
