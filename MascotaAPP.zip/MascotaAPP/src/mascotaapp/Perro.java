/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mascotaapp;

public class Perro extends Mascota implements MascotaInteractiva{
    
    //Constructor que hereda de mascota
    public Perro(String nombre, int edad) {
        super(nombre, edad);
    }

    public Perro() {
    }
   

    @Override
    public void hacerSonido() {
        System.out.println("El perro "+ nombre + " ladra y hace Guau.");
    }

    @Override
    public void jugar() {
        System.out.println("El perro "+ nombre + " juega con su huesito.");
    }

    @Override
    public void alimentar() {
        System.out.println("El perro "+ nombre + " va a comer croquetas.");
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
