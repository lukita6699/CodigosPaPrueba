/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mascotaapp;
import java.util.ArrayList;
import java.util.Scanner;
public class TiendaMascotas {
    
    private ArrayList <Mascota> listaMascotas;

    public TiendaMascotas() {
        this.listaMascotas = new ArrayList<>();//Inicializo la lista como vacia
    }
    
    public void agregarMascotas(Mascota instanciaMascota){
        listaMascotas.add( instanciaMascota);//Estoy agregando la ultima mascota creada.
    }
    
    public void mostrarMascotas(){
        for (Mascota instanciaMascota : listaMascotas){
            instanciaMascota.mostrarInfo();
            instanciaMascota.hacerSonido();
            
            //Estoy llamando una instancia de la interfas para poder utilizar sus metodos.
            //instanceof sirve para llamar a los metodos de la Interface.
            if (instanciaMascota instanceof MascotaInteractiva){//SI perro tiene implementada la interface MascotaInteractiva realiza..
                ((MascotaInteractiva)instanciaMascota).jugar();
                ((MascotaInteractiva)instanciaMascota).alimentar();
                
            }
            System.out.println("========================================================================");
        }
    }
    
    
    
    public void buscarMascotaPorNombre(){
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Ingrese el nombre de la mascota a buscar: ");
        String r = sc.nextLine();

        for (Mascota m : listaMascotas){
            if (m.nombre.equalsIgnoreCase(r)){
                System.out.println("La mascota "+r+" a sido encontrada exitosamente.");
                break;
            }else{
                System.out.println("La mascota no existe.");
                }
        }
    }
}

