/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package mascotaapp;

public interface MascotaInteractiva {
    //Al declarar una interface, netBeans asume que son metodos abstractos y publicos.
    //Interface es un tipo de contrato, que cualquiera o cualquier clase que lo implemente debe cumplirlo a cabalidad
    void jugar();
    void alimentar();
    
    
    
    
    
    
    
    
    
    
}
