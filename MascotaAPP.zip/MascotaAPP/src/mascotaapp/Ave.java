/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mascotaapp;

public class Ave extends Mascota implements MascotaInteractiva{

    public Ave(String nombre, int edad) {
        super(nombre, edad);
    }

    public Ave() {
    }

    @Override
    public void hacerSonido() {
        System.out.println("El ave "+ nombre +" canta");
    }

    @Override
    public void jugar() {
        System.out.println("El ave "+ nombre +" juega con otra ave.");
    }

    @Override
    public void alimentar() {
        System.out.println("El ave "+ nombre +" come gusanos.");
    }
    
    
    
    
}
