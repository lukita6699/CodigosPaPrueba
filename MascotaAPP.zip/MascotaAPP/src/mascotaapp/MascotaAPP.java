
package mascotaapp;

public class MascotaAPP {

    public static void main(String[] args) {
        
        TiendaMascotas tienda = new TiendaMascotas();
        
        //crear mascotas
        Mascota perro1 = new Perro ("Firu", 10);
        Mascota gato1 = new Gato ("Humberto Michu",5);
        Mascota ave1 = new Ave ("yaki",1);
        //Agregar mascotas a la lista 
        
        tienda.agregarMascotas(perro1);
        tienda.agregarMascotas(gato1);
        tienda.agregarMascotas(ave1);
        
        tienda.mostrarMascotas();
        
        tienda.buscarMascotaPorNombre();
        
        
        
        
        
    }
    
}
