/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mascotaapp;

public class Gato extends Mascota implements MascotaInteractiva{

    public Gato(String nombre, int edad) {
        super(nombre, edad);
    }

    public Gato() {
    }

    @Override
    public void hacerSonido() {
        System.out.println("El gato "+ nombre +" hace miau");
    }
    
    @Override
    public void jugar() {
        System.out.println("El gato "+ nombre +" juega con su raton.");
    } 

    @Override
    public void alimentar() {
        System.out.println("El gato "+ nombre +" va a comer atun.");
    }
    
    
}
