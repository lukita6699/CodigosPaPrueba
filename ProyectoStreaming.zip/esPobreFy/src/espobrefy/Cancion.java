/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package espobrefy;
/**
 *
 * @author Calfún
 */
public class Cancion {
    
    private String titulo,artista;
    private int duracion;
    private boolean favorita,descargada;

    //Método constructor con aprametros
    public Cancion(String titulo, String artista, int duracion, boolean favorita, boolean descargada) {
        this.titulo = titulo;
        this.artista = artista;
        this.duracion = duracion;
        this.favorita = favorita;
        this.descargada = descargada;
    }
    
    //Método constructor sin parametros.
    public Cancion() {
    }
    
    //Métodos Getter y Setter
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public boolean isFavorita() {
        return favorita;
    }

    public void setFavorita(boolean favorita) {
        this.favorita = favorita;
    }

    public boolean isDescargada() {
        return descargada;
    }

    public void setDescargada(boolean descargada) {
        this.descargada = descargada;
    }
    
    //Método customer que imprime la duración de la canción en minutos.
    public void imprimirCancion(){
        int minutos=this.duracion / 60;
        int segundos=this.duracion % 60;
        System.out.println("El titulo es: "+this.titulo);
        System.out.println("El artista es: "+this.artista);
        System.out.println("La duración es: "+minutos+":"+segundos+" segundos");
    }
    
    //Método customer que retorna si la canción es larga o no
    public String calcularCancion(){
        String mensaje="";
        if(this.duracion>=300){
            mensaje="La canción "+this.titulo+" es larga";
        }else{
            mensaje= "La canción "+this.titulo+" es normal";
        }
        return mensaje;
    }
    
    //Método custome que adelanta una canción
    public void adelantarCancion(int segundos){
        System.out.println("La canción se adelantó "+segundos+" segundos");
    }
    
    //Método toString
    @Override
    public String toString() {
        return "Cancion{" + "titulo=" + titulo + ", artista=" + artista + ", duracion=" + duracion + ", favorita=" + favorita + ", descargada=" + descargada + '}';
    }    
    
}
