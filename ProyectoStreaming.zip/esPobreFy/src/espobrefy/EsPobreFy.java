/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package espobrefy;

/**
 *
 * @author Calfún
 */
public class EsPobreFy {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Cancion cancion1=new Cancion("Las flores de tu florero","Los charros de Lumaco",324,true,true);
        Cancion cancion2=new Cancion();
        
        System.out.println(cancion1.toString());
        System.out.println(cancion2.toString());
        
        cancion1.imprimirCancion();
        
        cancion1.calcularCancion();
        
        cancion1.adelantarCancion(15);
    }
    
}
