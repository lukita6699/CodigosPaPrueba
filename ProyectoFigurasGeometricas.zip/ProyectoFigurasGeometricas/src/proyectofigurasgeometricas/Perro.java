/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofigurasgeometricas;

/**
 *
 * @author Calfún
 */
public class Perro implements IMetodos{
    
    private String nombre;
    private int edad;
    private double peso;

    public Perro(String nombre, int edad, double peso) {
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
    }

    public Perro() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    @Override
    public String toString() {
        return "Perro{" + "nombre=" + nombre + ", edad=" + edad + ", peso=" + peso + '}';
    }

    @Override
    public void mostrarDatos() {
        System.out.println("El nombres es:"+this.getNombre());
        System.out.println("La edad es: "+this.getEdad());
        System.out.println("EL peso es: "+this.getPeso());
    }

   
    
    
}
