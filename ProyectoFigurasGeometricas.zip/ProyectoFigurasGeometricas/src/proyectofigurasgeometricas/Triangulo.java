/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofigurasgeometricas;

/**
 *
 * @author Calfún
 */
public class Triangulo extends Figura {

    private int base;

    public Triangulo(String nombre, int base, int lado1, int lado2) {
        super(nombre, lado1, lado2);
        this.base = base;
    }

    public int calcularAltura() {
        //Aplicamos pitagoras para calcular altura.
        int altura = (int) Math.sqrt((base / 2) * (base / 2) + (lado1) * (lado1));
        return altura;
    }

    @Override
    public void calcularArea() {
        //Llamamos al método calcular altura
        int altura = calcularAltura();
        int area = (base * altura) / 2;
        System.out.println("El area es: " + area);
    }

    @Override
    public int calcularPerimetro() {
        //Sumar todos los lados
        int perimetro = base + lado1 + lado2;
        return perimetro;
    }

    @Override
    public void dibujarFigura() {
        //primer for para saber la altura
        int altura = calcularAltura();
        for (int i = 1; i <= altura; i++) {
            //Segundo for para imprimir espacios
            for (int j = 1; j <= altura - i; j++) {
                System.out.print(" ");
            }
            //Tercer for para imprimir los *
            for (int m = 1; m <= 2 * i - 1; m++) {
                System.out.print("*");
            }
            System.out.println("");
        }
    }

}
