/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectofigurasgeometricas;

/**
 *
 * @author Calfún
 */
public class ProyectoFigurasGeometricas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Figura figura1=new Cuadrado("Cuadrado",5);
       Figura figura2=new Rectangulo("Rectangulo",3,8);
    
       figura1.mostrarDatos();
       figura2.mostrarDatos();
       
       Perro perro1=new Perro("Cachupin",3,4.5);
       perro1.mostrarDatos();
       
       Figura triang=new Triangulo("Triangulo",4,5,5);
        triang.dibujarFigura();
    }
    
}
