/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofigurasgeometricas;

/**
 *
 * @author Calfún
 */
public class Rectangulo extends Figura  {

    public Rectangulo(String nombre, int lado1, int lado2) {
        super(nombre, lado1, lado2);
    }

    public Rectangulo() {
    }

    @Override
    public void calcularArea() {
    int area=lado1*lado2;
        System.out.println("El area es:"+area);
    }

    @Override
    public int calcularPerimetro() {
        int perimetro=(2*lado1)+(2*lado2);
        return perimetro;
    }

    @Override
    public void dibujarFigura() {
    for(int i=0;i<lado1;i++){
            for(int j=0;j<lado2;j++){
                System.out.print(" * ");
            }
            System.out.println("");
        }
    }      

    

   
}
