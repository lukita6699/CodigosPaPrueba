/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofigurasgeometricas;

/**
 *
 * @author Calfún
 */
public class Cuadrado extends Figura{

    public Cuadrado(String nombre, int lado1) {
        super(nombre, lado1);
    }

    
    
    @Override
    public void calcularArea() {
        int area=lado1*lado1;
        System.out.println("El área es: "+area);    
    }

    @Override
    public int calcularPerimetro() {
        int perimetro=4*lado1;
        return perimetro;
    }

    @Override
    public void dibujarFigura() {
        for(int i=0;i<lado1;i++){
            for(int j=0;j<lado1;j++){
                System.out.print(" * ");
            }
            System.out.println("");
        }
    }    
       
}
