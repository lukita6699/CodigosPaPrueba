/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofigurasgeometricas;

/**
 *
 * @author Calfún
 */
public abstract class Figura implements IMetodos {
    
    protected String nombre;
    protected int lado1;
    protected int lado2;

    //Constructor para el rectangulo
    public Figura(String nombre, int lado1, int lado2) {
        this.nombre = nombre;
        this.lado1 = lado1;
        this.lado2 = lado2;
    }

    //Constructor para el cuadrado
    public Figura(String nombre, int lado1) {
        this.nombre = nombre;
        this.lado1 = lado1;
    }
   
    public Figura() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getLado1() {
        return lado1;
    }

    public void setLado1(int lado1) {
        this.lado1 = lado1;
    }

    public int getLado2() {
        return lado2;
    }

    public void setLado2(int lado2) {
        this.lado2 = lado2;
    }
    //Método calcular el área
    public abstract void calcularArea();
    //Método calcular el perimetro
    public abstract int calcularPerimetro();
    //Método dibujar figura
    public abstract void dibujarFigura(); 
   
    
    @Override
    public final void mostrarDatos(){
        System.out.println("La figura es: "+this.getNombre());
        this.calcularArea();
        System.out.println("El perimetro es: "+this.calcularPerimetro());
        this.dibujarFigura();
    }
    
    @Override
    public String toString() {
        return "Figura{" + "nombre=" + nombre + ", lado1=" + lado1 + ", lado2=" + lado2 + '}';
    }
    
    
}
